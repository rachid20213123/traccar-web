export const snackBarDurationShortMs = 1500;
export const snackBarDurationLongMs = 2750;
